package net.apispark.cell30.version1.resource.server;

import org.restlet.resource.ServerResource;

/**
 * Defines common behaviour of server resources.
 */
public abstract class AbstractServerResource extends ServerResource {


}
